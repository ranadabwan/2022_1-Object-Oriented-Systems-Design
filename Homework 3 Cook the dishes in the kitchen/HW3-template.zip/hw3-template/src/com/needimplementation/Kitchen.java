package com.needimplementation;

// TODO Implement this class, do not modify the existing code but only add from it
public class Kitchen {

  public void cook(Order o) {
  }

  public boolean isAllOrderFinished() {

  }

  public Order[] getAllUnfinishedOrders() {

  }
}
